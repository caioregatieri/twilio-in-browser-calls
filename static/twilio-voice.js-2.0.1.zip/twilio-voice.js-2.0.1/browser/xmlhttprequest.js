'use strict';
module.exports = { XMLHttpRequest: XMLHttpRequest };
