'use strict';
module.exports = WebSocket;
