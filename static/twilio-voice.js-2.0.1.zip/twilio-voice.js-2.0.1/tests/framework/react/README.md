twiliojs-react
==================

This is the Test Application for ensuring that twilio-client.js works with React.
The project was created with `create-react-app`, and then further reduced to the
bare essentials.

Usage
-----

Install the project with

```
npm install
```

and then start the application server with

```
npm start
```

The application expects an Access Token to be provided via a `token` query
parameter.
