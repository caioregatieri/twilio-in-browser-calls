twilio-client-no-framework
=========================

This is the Test Application for ensuring that twilio-client.js works without any
Test Framework.

Usage
-----

Install the project with

```
npm install
```

and then start the application server with

```
npm start
```

The application expects an Access Token to be provided via a `token` query
parameter.
