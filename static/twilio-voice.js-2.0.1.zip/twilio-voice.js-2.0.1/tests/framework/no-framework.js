'use strict';
require('./')(require('./no-framework.json'));
