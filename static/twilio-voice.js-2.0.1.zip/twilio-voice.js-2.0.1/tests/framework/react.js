'use strict';
require('./')(require('./react.json'));
