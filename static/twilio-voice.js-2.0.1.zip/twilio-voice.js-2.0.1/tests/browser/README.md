# Browser Tests

Browser Tests ensure certain twilio.js bugs stay fixed across browsers:

* Chrome
* Firefox

Issues currently under test:
 * [CLIENT-3475](https://issues.corp.twilio.com/browse/CLIENT-3475) - Setting an alert on
     `Device.incoming` should not prevent the sound from playing.
