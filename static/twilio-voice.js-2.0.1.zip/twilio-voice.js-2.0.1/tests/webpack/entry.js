const Device = require('../../').Device;
