module.exports = {
  entry: './entry.js',
  stats: {
    warnings: false
  }
};
