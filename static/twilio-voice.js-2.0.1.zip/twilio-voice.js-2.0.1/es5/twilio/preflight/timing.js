"use strict";
/**
 * @packageDocumentation
 * @module Voice
 * @publicapi
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=timing.js.map