export var COWBELL_AUDIO_URL: string;
export var ECHO_TEST_DURATION: number;
export var PACKAGE_NAME: string;
export var RELEASE_VERSION: string;
export var SOUNDS_BASE_URL: string;
export var USED_ERRORS: string[];
